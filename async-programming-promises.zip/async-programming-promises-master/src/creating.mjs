import setText, { appendText } from "./results.mjs";

export function timeout(){
}

export function interval(){
}

export function clearIntervalChain(){
}

export function xhr(){
}

export function allPromises(){
}

export function allSettled(){
}

export function race(){
}